
export const authorize = (allowedRoles: string[]) => {
  return (req: any, res: any, next: any) => {
    const userRole = req.user?.role;
    if (!allowedRoles.includes(userRole)) {
      return res.status(403).json({ error: "Access denied" });
    }
    next();
  };
};
