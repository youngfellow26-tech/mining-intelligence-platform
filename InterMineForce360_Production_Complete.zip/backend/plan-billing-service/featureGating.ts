
export interface Plan {
  name: string;
  features: string[];
}

export const hasFeature = (plan: Plan, feature: string): boolean => {
  return plan.features.includes(feature);
};
