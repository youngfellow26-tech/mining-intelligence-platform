
import express from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { v4 as uuidv4 } from 'uuid';

const app = express();
app.use(express.json());

const SECRET = process.env.JWT_SECRET || "super_secret_key";

interface User {
  id: string;
  email: string;
  passwordHash: string;
  role: string;
}

const users: User[] = [];

app.post('/register', async (req, res) => {
  const { email, password, role } = req.body;
  const passwordHash = await bcrypt.hash(password, 10);
  const newUser = { id: uuidv4(), email, passwordHash, role };
  users.push(newUser);
  res.status(201).json({ message: "User created" });
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email);
  if (!user) return res.status(401).json({ error: "Invalid credentials" });

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) return res.status(401).json({ error: "Invalid credentials" });

  const token = jwt.sign({ id: user.id, role: user.role }, SECRET, { expiresIn: '1h' });
  res.json({ token });
});

app.listen(4000, () => console.log("Auth Service running on port 4000"));
