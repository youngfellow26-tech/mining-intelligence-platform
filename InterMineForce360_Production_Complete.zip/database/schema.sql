
CREATE TABLE tenants (
  id UUID PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE users (
  id UUID PRIMARY KEY,
  tenant_id UUID REFERENCES tenants(id),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE plans (
  id UUID PRIMARY KEY,
  name TEXT NOT NULL,
  max_users INT,
  features TEXT[]
);

CREATE TABLE subscriptions (
  id UUID PRIMARY KEY,
  tenant_id UUID REFERENCES tenants(id),
  plan_id UUID REFERENCES plans(id),
  status TEXT,
  started_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE production_logs (
  id UUID PRIMARY KEY,
  tenant_id UUID REFERENCES tenants(id),
  mine_name TEXT,
  tonnage NUMERIC,
  logged_at TIMESTAMP DEFAULT NOW()
);
